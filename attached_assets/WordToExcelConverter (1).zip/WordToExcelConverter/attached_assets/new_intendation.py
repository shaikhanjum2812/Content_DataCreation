import os
from docx import Document

def extract_code_with_indentation(docx_file):
    """
    Extracts C code blocks from a Word document and maintains the original indentation.
    
    Args:
    docx_file: str - The path to the Word document (.docx).
    
    Returns:
    queries: list of dicts - A list of dictionaries containing the filename and extracted code.
    """
    document = Document(docx_file)
    queries = []
    query_count = 9
    collecting_code = False
    current_code = []

    for paragraph in document.paragraphs:
        text = paragraph.text

        if text.startswith("Code:"):  # Start of a code block
            collecting_code = True
            current_code = []  # Reset current code collection

        elif "Answer the following questions:" in text and collecting_code:
            # End of a code block
            qlocation = f"JBSV{query_count}.txt"
            queries.append({
                "qlocation": qlocation,
                "code": "\n".join(current_code)  # Preserve original line formatting
            })
            query_count += 1
            collecting_code = False  # Reset flag
            current_code = []  # Reset collection for the next code block

        elif collecting_code:
            current_code.append(text)  # Collect lines with original indentation

    return queries

def create_text_files_from_code(queries, output_dir):
    """
    Creates text files from extracted code blocks and saves them in a specified folder.
    
    Args:
    queries: list of dicts - List of extracted code blocks and filenames.
    output_dir: str - The directory where the files will be saved.
    """
    # Create the output directory if it doesn't exist
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    for query in queries:
        file_path = os.path.join(output_dir, query["qlocation"])
        with open(file_path, 'w') as file:
            file.write(query["code"])
        print(f"File created: {file_path}")

# Example usage
if __name__ == "__main__":
    # Specify the path to your Word document
    docx_file = "E:/Java/New_Addition/Scope of variable/Scope of variable.docx"  # Replace with your actual path
    
    # Specify the output folder
    output_folder = "E:/Java/New_Addition/Scope of variable/Code"  # Replace with your desired folder name
    
    # Extract code blocks from the Word document
    extracted_code = extract_code_with_indentation(docx_file)
    
    # Create the text files with the extracted code in the specified folder
    create_text_files_from_code(extracted_code, output_folder)
