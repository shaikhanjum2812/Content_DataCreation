import pandas as pd
from docx import Document
import openpyxl
import os

# Function to extract data for Sheet1 (ex_data)
def extract_ex_data_from_docx(docx_path):
    document = Document(docx_path)
    ex_data = []
    
    current_entry = {}
    collecting_description = False
    
    for para in document.paragraphs:
        text = para.text.strip()
        
        if text.startswith("exid :"):
            if current_entry:
                ex_data.append(current_entry)
            current_entry = {'exid': text.split("exid :")[1].strip()}
            collecting_description = False
        elif text.startswith("title :"):
            current_entry['title'] = text.split("title :")[1].strip()
            collecting_description = False
        elif text.startswith("description :"):
            current_entry['description'] = text.split("description :")[1].strip()
            collecting_description = True
        elif text.startswith("category :"):
            current_entry['category'] = text.split("category :")[1].strip()
            collecting_description = False
        elif text.startswith("subcategoryid :"):
            current_entry['subcategoryid'] = text.split("subcategoryid :")[1].strip()
            collecting_description = False
        elif text.startswith("level :"):
            current_entry['level'] = int(text.split("level :")[1].strip())
            collecting_description = False
        elif text.startswith("language :"):
            current_entry['language'] = text.split("language :")[1].strip()
            collecting_description = False
        elif text.startswith("qlocation :"):
            current_entry['qlocation'] = text.split("qlocation :")[1].strip()
            collecting_description = False
        elif text.startswith("module :"):
            current_entry['module'] = text.split("module :")[1].strip()
            collecting_description = False
        elif text.startswith("ex_seq :"):
            current_entry['ex_seq'] = int(text.split("ex_seq :")[1].strip())
            collecting_description = False
        elif text.startswith("cat_seq :"):
            current_entry['cat_seq'] = int(text.split("cat_seq :")[1].strip())
            collecting_description = False
        elif text.startswith("subcat_seq :"):
            current_entry['subcat_seq'] = int(text.split("subcat_seq :")[1].strip())
            collecting_description = False
        elif text.startswith("league :"):
            current_entry['league'] = text.split("league :")[1].strip()
            collecting_description = False
        elif text.startswith("labels :"):
            current_entry['labels'] = text.split("labels :")[1].strip()
            collecting_description = False
        elif collecting_description:
            current_entry['description'] += "\n" + text  # Add a line break before appending the next line
    
    if current_entry:
        ex_data.append(current_entry)
    
    return ex_data

# Function to extract data from the Word document for Sheet2 (qa_data)
def extract_assert_data(docx_path):
    document = Document(docx_path)
    qa_data = []
    
    exid = ""
    key = 1
    label = ""

    for para in document.paragraphs:
        text = para.text.strip()
        
        if text.startswith("exid :"):
            exid = text.split("exid :")[1].strip()
            key = 1
        elif text.startswith("description :"):
            # Extract the label after 'Function'
            if "Function" in text:
                label_start = text.find("Function") + len("Function")
                label = text[label_start:].strip().split()[0].rstrip('()')  # Extract function name without parentheses
        elif "assert" in text:
            # Appending the data as a new row
            qa_data.append([exid, key, label, 'assert', '', text])
            key += 1
            
    return qa_data

# Paths to the Word document and the Excel file
docx_path = "E:/Challenger_Debug (1).docx"  # Update this path with your document's path
excel_path = "E:/Challenger_Debug (1).xlsx"  # Update this path with your Excel file's path

# Extract data from the Word document
ex_data = extract_ex_data_from_docx(docx_path)
qa_data = extract_assert_data(docx_path)

# Convert extracted data to DataFrames
df_ex_data = pd.DataFrame(ex_data)
columns_qa_data = ['exid', 'key', 'label', 'type', 'options', 'answer']
df_qa_data = pd.DataFrame(qa_data, columns=columns_qa_data)

# Check if the Excel file exists
if not os.path.exists(excel_path):
    # Create a new Excel file
    with pd.ExcelWriter(excel_path, engine='openpyxl') as writer:
        df_ex_data.to_excel(writer, sheet_name='ex_data', index=False)
        df_qa_data.to_excel(writer, sheet_name='qa_data', index=False)
else:
    # Load the existing Excel file and write to 'ex_data' and 'qa_data' sheets
    with pd.ExcelWriter(excel_path, engine='openpyxl', mode='a', if_sheet_exists='replace') as writer:
        df_ex_data.to_excel(writer, sheet_name='ex_data', index=False)
        df_qa_data.to_excel(writer, sheet_name='qa_data', index=False)

print("Excel file updated successfully!")
